<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM barang");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cv</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"> <img src="sella.jpeg.jpeg" alt="My Idol">
    </div>
    <?php
    foreach ($cari as $cari2):
    ?>

    <h1>nama <?= $cari2 ['nama'];?></h1>
    <h3>hobi <?= $cari2 ['hobi'];?></h3>
    <?php
    endforeach;
    ?>

    </div>
    <div class="main">
        <div class="left">
            <h2>identitas</h2>
            <p><strong>nama </strong><?= $cari2 ['nama'];?></p>
            <p><strong>alamat </strong><?php echo $cari2 ['alamat'];?></p>
            <p><strong>no.telepon </strong><?php echo $cari2 ['no_tlpn'];?></p>
            <p><strong>skil </strong><?php echo $cari2 ['skil'];?></p>
            <h2>pendidikan</h2>
            <p><strong>sekolah dasar </strong>sd 81 kota jambi</p>
            <p><strong>sekolah menengah pertama </strong>smp 20 kota jambi</p>
            <p><strong>sekolah menengah kejuruan </strong>smk 6 kota jambi</p>
        </div>
        <div class="right">
            <h2>pekerjaan</h2>
            <p><strong>dirumah </strong>mencuci piring</p>
            <p><strong>disekola </strong>belajar</p>
            <h3>kepribadian </h3>
            <p><strong>sifat </strong>saya</p>
            <li>tidak suka marah</li>
            <li>baik</li>
            <li>tidak sombong</li>




        </div>
    </div>
    </div>
</body>
</html>