<?php
session_start();
$database= mysqli_connect('localhost','root','','toko');
if (isset ($_POST["tombol"])){
    $username = $_POST ["username"];
    $password = $_POST ["password"];
    $cari = mysqli_query ($database,"SELECT * FROM user WHERE
    username = '$username' and password = '$password'");

    if (mysqli_num_rows ($cari)=== 1){
        $_SESSION ["login"]= true;
        header ("Location: index.php");
        exit;
    }
    $error = true;
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
</head>
<body>
    <h1>Halaman Login</h1>
    <?php if (isset($error)): ?>
<p>User / Password Salah</p>
<?php endif; ?>

    <form action="" method="post">
        <label for="">Username</label>
        <input type="text" name="username">
        <label for="">Password</label>
        <input type="password" name="password">
        <button type="submit" name="tombol">Login</button>
    </form>
</body>
</html>